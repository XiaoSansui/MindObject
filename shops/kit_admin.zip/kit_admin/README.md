# kit_admin
基于layui 2.x 的后台管理模板

## Build Setup

``` bash
# install dependencies
npm install

# serve with hot reload at localhost:8000
npm start

# build for production with minification
npm run build

```